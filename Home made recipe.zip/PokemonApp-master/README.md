# Pokemon App

Pokemon App with animations, beautiful UI and network call.

## YouTube Tutorials
### Hindi
[Build a beautiful Pokemon App](https://youtu.be/0K3Zq3XqdAo)
### English
[Build a beautiful Pokemon App](https://youtu.be/yeXJqZCiwTQ)

## Screenshots

<img src="ss2.png" height="500em" /><img src="ss.png" height="500em" />


## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
